const WebSocket = require("ws");
const { randomUUID } = require("crypto");

const PORT = Number(process.env.PORT || 8080);
const wss = new WebSocket.Server({ port: PORT });
const players = new Map();

function send(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
}
function snapshot() {
  const result = {};
  for (const [id, p] of players.entries()) result[id] = p;
  return result;
}
function broadcastSnapshot() {
  const message = { type: "snapshot", players: snapshot() };
  for (const client of wss.clients) send(client, message);
}

wss.on("connection", (ws) => {
  let assignedId = null;
  ws.on("message", (buffer) => {
    let msg;
    try { msg = JSON.parse(buffer.toString()); } catch { return; }
    if (!msg || typeof msg.type !== "string") return;

    if (msg.type === "join") {
      const requested = String(msg.id || randomUUID()).slice(0, 48);
      assignedId = requested;
      players.set(assignedId, {
        id: assignedId,
        name: String(msg.name || "New Hustler").slice(0, 24),
        x: 0, y: 1, z: 10, cash: 25000
      });
      send(ws, { type: "welcome", id: assignedId, cash: players.get(assignedId).cash });
      broadcastSnapshot();
      return;
    }

    if (!assignedId || !players.has(assignedId)) return;
    const player = players.get(assignedId);

    if (msg.type === "move") {
      // Validate and clamp client movement; this is a prototype, not production anti-cheat.
      const num = (v, fallback) => Number.isFinite(Number(v)) ? Number(v) : fallback;
      player.name = String(msg.name || player.name).slice(0, 24);
      player.x = Math.max(-45, Math.min(45, num(msg.x, player.x)));
      player.y = Math.max(0, Math.min(5, num(msg.y, player.y)));
      player.z = Math.max(-45, Math.min(45, num(msg.z, player.z)));
      broadcastSnapshot();
    }

    if (msg.type === "cash_update") {
      // Temporary demo only: never trust client-supplied balances in a real game.
      player.cash = Math.max(0, Math.min(100000000, Number(msg.cash) || player.cash));
      send(ws, { type: "welcome", cash: player.cash });
    }
  });

  ws.on("close", () => {
    if (assignedId) players.delete(assignedId);
    broadcastSnapshot();
  });
});

console.log(`EKO prototype WebSocket server listening on ws://localhost:${PORT}`);
