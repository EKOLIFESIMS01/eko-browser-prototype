# EKO — First Public Release Deployment Checklist

## Release scope

This is a prototype, not a complete commercial game. The first public milestone should be a browser demo for a small number of testers. The current WebSocket server is a demo relay and does not provide secure accounts or a trustworthy economy.

## 1. Free accounts and tools

Create these yourself:
- GitHub account: https://github.com/
- Render account: https://render.com/
- Install Godot 4.x and its matching export templates: https://godotengine.org/download
- Install Node.js 18 or newer: https://nodejs.org/

Never send passwords, API keys, signing keys, payment information, or account recovery codes in chat.

## 2. Test locally first

1. Extract the ZIP.
2. Import `project.godot` in Godot 4.x.
3. Run the project and check movement, camera, wallet and hustle button.
4. Open a terminal in `server/` and run `npm install`, then `npm start`.
5. Launch a second game instance. Verify that the two instances can see each other.
6. Check the Godot debugger for errors. Fix any errors before public deployment.

This project has not been validated on all platforms. Treat local testing as a required step.

## 3. Export a web build

1. In Godot, install export templates matching your exact Godot version.
2. Open Project > Export.
3. Add a Web preset.
4. Use the Compatibility renderer and a single-threaded web export for the simplest hosting setup.
5. Export the game into a folder named `web/` in the repository.
6. Verify that `web/index.html` and all generated `.wasm`, `.pck`, JavaScript and supporting files are present.
7. Test the export locally using a web server, not by opening `index.html` directly from the filesystem.

The `web/` folder is generated output and is ignored by `.gitignore`; remove `web/` from `.gitignore` if you choose to commit the exported build. Alternatively, deploy the generated folder directly through the hosting provider's dashboard.

## 4. Deploy the multiplayer server on Render

1. Push the project to a private or public GitHub repository.
2. In Render, choose New > Web Service and connect the repository.
3. Set Root Directory to `server`.
4. Set Build Command to `npm install`.
5. Set Start Command to `npm start`.
6. Choose the Free instance for a prototype.
7. Deploy. Render assigns a public service URL such as `https://your-service.onrender.com`.
8. The WebSocket endpoint is normally `wss://your-service.onrender.com` on the same host and port.
9. Edit `SERVER_URL` in `scripts/main.gd` to that `wss://` URL.
10. Re-export the web build and redeploy it.
11. Confirm the deployed server accepts WebSocket connections from the deployed website.

Do not use `ws://127.0.0.1:8080` for public clients. That address points to each player's own device, not your hosted server.

Free Render services can sleep, and local files on free services are not durable. Do not use this prototype for valuable player accounts, long-term saves, or real-money purchases.

## 5. Deploy the website

1. In Render, choose New > Static Site and connect the same repository.
2. Set the publish directory to `web` (after exporting the game there).
3. Leave the build command empty if you commit/upload the finished export; otherwise use a build workflow that generates the folder.
4. Deploy and open the generated HTTPS URL.
5. Test the game on desktop Chrome/Firefox and on an Android phone.
6. Confirm browser console has no loading, WebGL, CORS or WebSocket errors.

Keep the website on HTTPS and the multiplayer endpoint on WSS.

## 6. Required before public multiplayer testing

The current server trusts client-supplied cash updates. This is intentionally a demo shortcut and is not secure. Before inviting the public:
- Move job rewards and balance changes to server-authoritative code.
- Add accounts and a persistent database.
- Validate movement, rate-limit messages and protect against impersonation.
- Add reconnect handling, moderation, block/report features and privacy disclosures.
- Configure TLS/WSS, logging, backups and abuse monitoring.
- Add age-appropriate chat and relationship safeguards.
- Do not add real-money payments or cash-out until the game economy, provider policies, fraud prevention and applicable legal obligations have been reviewed.

## 7. Platform-specific releases

### Windows / PC
- Add a Windows Desktop export preset in Godot.
- Export the executable and its required data files.
- Test on a clean Windows machine.
- Sign the executable if distributing broadly; code signing may incur fees.

### Android
- Install/configure Android SDK and JDK in Godot.
- Add Android export preset, package identifier, app icon and version.
- Export APK for private testing; use AAB for Google Play submission.
- Play Console registration generally has a one-time US$25 fee; verify the current requirements during registration.
- Complete Play Console identity verification, content rating, privacy/data-safety forms and any required testing track.

### iOS
- Requires access to a Mac running Xcode for the native build and signing process.
- Add an iOS export preset, bundle identifier, app icons and signing configuration.
- Apple Developer Program membership is generally US$99/year, subject to regional pricing and eligibility.
- Upload via Apple's required tools, test with TestFlight and submit for App Review.

### Web
- Publish the exported Godot Web files on an HTTPS static host.
- Keep the browser build compatible with WebGL 2.0 and the chosen export settings.
- A custom domain is optional and usually costs money; the host's generated subdomain can be used for a prototype.

## 8. Required files at release time

Source files:
- `project.godot`
- `scenes/main.tscn`
- `scripts/main.gd`
- `server/package.json`
- `server/server.js`
- `README.md`

Generated/release files:
- `web/index.html` plus every other file produced by the Godot Web export
- Windows executable plus required data files
- Android APK for direct testing and/or signed AAB for Play Console
- iOS Xcode project/archive built and signed on macOS
- Store icon, screenshots, descriptions, privacy policy URL and support contact

The iOS/Android signing files and credentials must be kept private. Never commit them to GitHub.

## Current status

Included: starter source code and a minimal WebSocket relay.
Not yet done: verified clean build, public server deployment, web export, persistent accounts, secure server-side economy, mobile touch controls, signed mobile packages, store listings, store approvals or public launch.
