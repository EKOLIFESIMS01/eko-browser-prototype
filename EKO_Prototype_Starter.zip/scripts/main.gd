extends Node3D

const STARTING_CASH := 25000
const MOVE_SPEED := 5.0
const SERVER_URL := "ws://127.0.0.1:8080"

var player_id := ""
var cash := STARTING_CASH
var ws := WebSocketPeer.new()
var connected := false
var last_send := 0.0
var send_interval := 0.10
var position_by_id: Dictionary = {}
var remote_nodes: Dictionary = {}
var player: CharacterBody3D
var camera: Camera3D
var wallet_label: Label
var status_label: Label
var help_label: Label
var job_button: Button
var connect_button: Button
var name_input: LineEdit
var job_cooldown := 0.0

func _ready() -> void:
    randomize()
    player_id = "eko_%06d" % randi_range(100000, 999999)
    _build_world()
    _build_player()
    _build_ui()
    _connect_server()

func _process(delta: float) -> void:
    _poll_network()
    if camera != null and player != null:
        camera.global_position = player.global_position + Vector3(0, 9, 13)
        camera.look_at(player.global_position + Vector3(0, 1, 0), Vector3.UP)
    last_send += delta
    job_cooldown = maxf(0.0, job_cooldown - delta)
    if connected and last_send >= send_interval:
        last_send = 0.0
        _send_state()
    _update_remote_players()

func _physics_process(delta: float) -> void:
    if player == null:
        return
    var input_dir := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    var direction := Vector3(input_dir.x, 0, input_dir.y).normalized()
    player.velocity.x = direction.x * MOVE_SPEED
    player.velocity.z = direction.z * MOVE_SPEED
    if not player.is_on_floor():
        player.velocity.y -= 20.0 * delta
    else:
        player.velocity.y = -0.1
    player.move_and_slide()
    if direction.length() > 0.05:
        player.rotation.y = atan2(direction.x, direction.z)

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("interact"):
        _try_hustle()

func _build_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.76, 0.82)
    env.ambient_light_energy = 0.8
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -25, 0)
    sun.light_energy = 1.2
    add_child(sun)

    _add_box("Ground", Vector3(0, -0.25, 0), Vector3(100, 0.5, 100), Color(0.30, 0.48, 0.25))
    _add_box("Road", Vector3(0, 0.015, 0), Vector3(10, 0.05, 90), Color(0.18, 0.18, 0.19))
    _add_box("CrossRoad", Vector3(0, 0.02, 0), Vector3(90, 0.06, 8), Color(0.18, 0.18, 0.19))
    for z in range(-40, 45, 8):
        _add_box("RoadMark", Vector3(0, 0.06, z), Vector3(0.25, 0.02, 3), Color(0.95, 0.83, 0.35))
    var colors = [Color(0.83,0.56,0.32), Color(0.77,0.72,0.55), Color(0.58,0.68,0.72), Color(0.84,0.75,0.59)]
    for i in range(8):
        var side := -1.0 if i % 2 == 0 else 1.0
        var zpos := -28.0 + float(i) * 8.0
        _add_house(Vector3(side * 12.0, 0, zpos), colors[i % colors.size()], "House_%d" % i)
    _add_shop(Vector3(7.5, 0, 3), "Mama Titi's Shop", Color(0.89, 0.55, 0.20))
    _add_shop(Vector3(-7.5, 0, -5), "Street Stall", Color(0.28, 0.60, 0.42))
    _add_sign(Vector3(0, 3.4, -18), "MUSHIN")

    camera = Camera3D.new()
    camera.name = "Camera3D"
    camera.position = Vector3(0, 9, 13)
    camera.rotation_degrees = Vector3(-25, 0, 0)
    camera.current = true
    add_child(camera)

func _add_box(label: String, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = label
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mesh_instance.material_override = mat
    add_child(mesh_instance)

    # Matching static collision lets the character stand on the ground and
    # keeps the player from walking through the larger buildings.
    var static_body := StaticBody3D.new()
    static_body.name = label + "_Collision"
    static_body.position = pos
    var collision := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    collision.shape = box_shape
    static_body.add_child(collision)
    add_child(static_body)
    return mesh_instance

func _add_house(pos: Vector3, color: Color, label: String) -> void:
    _add_box(label, pos + Vector3(0, 2, 0), Vector3(6, 4, 5), color)
    _add_box(label + "_Roof", pos + Vector3(0, 4.3, 0), Vector3(6.5, 0.5, 5.5), Color(0.36, 0.20, 0.16))
    _add_box(label + "_Door", pos + Vector3(0, 1, 2.54), Vector3(1, 2, 0.1), Color(0.25, 0.15, 0.10))
    _add_box(label + "_Window", pos + Vector3(-1.8, 2.3, 2.55), Vector3(1, 0.8, 0.1), Color(0.22, 0.65, 0.78))

func _add_shop(pos: Vector3, label: String, color: Color) -> void:
    _add_box(label, pos + Vector3(0, 1.2, 0), Vector3(3.5, 2.4, 3), color)
    _add_box(label + "_Awning", pos + Vector3(0, 2.55, 1.1), Vector3(4, 0.25, 1.8), Color(0.83, 0.18, 0.15))
    _add_box(label + "_Counter", pos + Vector3(0, 0.65, 1.7), Vector3(3.1, 1.1, 0.3), Color(0.36, 0.23, 0.13))

func _add_sign(pos: Vector3, words: String) -> void:
    var sign := Label3D.new()
    sign.text = words
    sign.font_size = 64
    sign.position = pos
    sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    sign.modulate = Color(1.0, 0.9, 0.55)
    add_child(sign)

func _build_player() -> void:
    player = CharacterBody3D.new()
    player.name = "LocalPlayer"
    player.position = Vector3(0, 1, 10)
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.45
    capsule.height = 1.8
    var body := MeshInstance3D.new()
    body.mesh = capsule
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.24, 0.44, 0.88)
    body.material_override = mat
    body.position.y = 0.9
    player.add_child(body)
    var collider := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.45
    shape.height = 1.8
    collider.shape = shape
    collider.position.y = 0.9
    player.add_child(collider)
    add_child(player)

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(16, 16)
    panel.custom_minimum_size = Vector2(300, 165)
    layer.add_child(panel)
    var vbox := VBoxContainer.new()
    panel.add_child(vbox)
    var title := Label.new()
    title.text = "EKO  |  MUSHIN LIFE"
    title.add_theme_font_size_override("font_size", 22)
    vbox.add_child(title)
    wallet_label = Label.new()
    vbox.add_child(wallet_label)
    status_label = Label.new()
    vbox.add_child(status_label)
    name_input = LineEdit.new()
    name_input.placeholder_text = "Choose your player name"
    name_input.text = "New Hustler"
    vbox.add_child(name_input)
    connect_button = Button.new()
    connect_button.text = "Connect / Reconnect"
    connect_button.pressed.connect(_connect_server)
    vbox.add_child(connect_button)
    job_button = Button.new()
    job_button.text = "Hustle: sell snacks (+₦2,000)"
    job_button.pressed.connect(_try_hustle)
    vbox.add_child(job_button)
    help_label = Label.new()
    help_label.text = "Move: WASD / arrows   |   Hustle: E"
    vbox.add_child(help_label)
    _refresh_ui()

func _connect_server() -> void:
    if ws.get_ready_state() == WebSocketPeer.STATE_CONNECTING or ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
        ws.close()
        ws = WebSocketPeer.new()
    var err := ws.connect_to_url(SERVER_URL)
    if err != OK:
        status_label.text = "Server connection failed. Start server in /server."
        connected = false

func _poll_network() -> void:
    ws.poll()
    var state := ws.get_ready_state()
    if state == WebSocketPeer.STATE_OPEN:
        if not connected:
            connected = true
            var join_msg := {"type":"join", "id":player_id, "name":name_input.text.strip_edges()}
            ws.send_text(JSON.stringify(join_msg))
        while ws.get_available_packet_count() > 0:
            var raw := ws.get_packet().get_string_from_utf8()
            var parsed = JSON.parse_string(raw)
            if parsed is Dictionary:
                _handle_server_message(parsed)
    elif state == WebSocketPeer.STATE_CLOSED:
        connected = false
    _refresh_ui()

func _handle_server_message(data: Dictionary) -> void:
    match data.get("type", ""):
        "welcome":
            if data.has("cash"):
                cash = int(data.cash)
        "snapshot":
            var players = data.get("players", {})
            for id in players.keys():
                if id != player_id:
                    position_by_id[id] = players[id]
            for id in position_by_id.keys():
                if not players.has(id):
                    position_by_id.erase(id)
                    if remote_nodes.has(id):
                        remote_nodes[id].queue_free()
                        remote_nodes.erase(id)

func _send_state() -> void:
    if ws.get_ready_state() != WebSocketPeer.STATE_OPEN:
        return
    ws.send_text(JSON.stringify({
        "type":"move",
        "id":player_id,
        "name":name_input.text.strip_edges(),
        "x":player.global_position.x,
        "y":player.global_position.y,
        "z":player.global_position.z
    }))

func _update_remote_players() -> void:
    for id in position_by_id.keys():
        var data: Dictionary = position_by_id[id]
        if not remote_nodes.has(id):
            var remote := Node3D.new()
            remote.name = "Remote_" + str(id)
            var mesh := MeshInstance3D.new()
            var capsule := CapsuleMesh.new()
            capsule.radius = 0.45
            capsule.height = 1.8
            mesh.mesh = capsule
            var mat := StandardMaterial3D.new()
            mat.albedo_color = Color(0.88, 0.36, 0.26)
            mesh.material_override = mat
            mesh.position.y = 0.9
            remote.add_child(mesh)
            var tag := Label3D.new()
            tag.text = str(data.get("name", "Player"))
            tag.position.y = 2.2
            tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
            remote.add_child(tag)
            add_child(remote)
            remote_nodes[id] = remote
        var target := Vector3(float(data.get("x", 0)), float(data.get("y", 1)), float(data.get("z", 0)))
        remote_nodes[id].global_position = remote_nodes[id].global_position.lerp(target, 0.35)
        var label_node = remote_nodes[id].get_child(1)
        if label_node is Label3D:
            label_node.text = str(data.get("name", "Player"))

func _try_hustle() -> void:
    if job_cooldown > 0.0:
        status_label.text = "Take a breather before the next hustle."
        return
    cash += 2000
    job_cooldown = 10.0
    _refresh_ui()
    if connected and ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
        ws.send_text(JSON.stringify({"type":"cash_update", "id":player_id, "cash":cash}))
    status_label.text = "You sold snacks and earned ₦2,000."

func _refresh_ui() -> void:
    if wallet_label:
        wallet_label.text = "Virtual wallet: ₦%s" % _format_number(cash)
    if status_label:
        status_label.text = "Online: %s  |  Players nearby: %d" % ["YES" if connected else "NO", remote_nodes.size()]

func _format_number(number: int) -> String:
    var s := str(number)
    var result := ""
    var count := 0
    for i in range(s.length() - 1, -1, -1):
        result = s[i] + result
        count += 1
        if count % 3 == 0 and i > 0:
            result = "," + result
    return result
