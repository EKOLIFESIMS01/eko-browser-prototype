# EKO — From the Trenches to the Top (Prototype)

A free starter project for a stylized 3D Nigerian life simulation. Built with Godot 4 and a small Node.js WebSocket server.

## What is included

- Procedurally generated 3D neighbourhood block: road, simple houses and stalls.
- Third-person capsule character with keyboard movement.
- Starting virtual wallet of ₦25,000.
- Demo snack-selling hustle that awards ₦2,000 (with a cooldown).
- WebSocket connection and basic player position replication.
- A minimal server that relays connected player states.

## What is NOT included yet

- This is not a complete game and has not been tested on every platform.
- No production account system, database, secure economy, anti-cheat, matchmaking or moderation.
- The demo cash update is client-trusted and must not be used with real money.
- No cars, full relationship/family simulation, real estate purchase/building, state travel, mature crime missions or app-store packaging.
- No touch joystick yet; mobile input needs to be added and tested.
- `127.0.0.1` works only when the game client and server run on the same computer. For online play, deploy the server and set `SERVER_URL` in `scripts/main.gd` to its secure `wss://` URL.

## Requirements

- Godot 4.3 or later (free): https://godotengine.org/download
- Node.js 18 or later (free): https://nodejs.org/

## Run locally

1. Open Godot Project Manager.
2. Click **Import** and select this folder's `project.godot`.
3. Open the project and run it (F6/F5 or the Play button).
4. In a terminal, open the `server` folder and run:

   ```bash
   npm install
   npm start
   ```

5. The client is configured for `ws://127.0.0.1:8080`. If the server starts after the game, click **Connect / Reconnect**.

To test multiplayer on one computer, launch two game instances. Both connect to the same local server and should see each other's capsule avatars.

## Controls

- WASD or arrow keys: move.
- E or the Hustle button: sell snacks and earn ₦2,000 virtual money.
- Type a display name before connecting.

## Export targets

Godot supports Android, iOS, desktop and Web exports. Each target needs its corresponding export template/toolchain:
- PC: install the Godot export templates and export Windows/macOS/Linux.
- Android: configure Android SDK/JDK in Godot Editor settings.
- iOS: export through Godot and finish signing/building with Xcode on macOS.
- Web: install export templates and export Web. Use HTTPS hosting; browser WebSocket connections to a public server should use `wss://`.

A single shared codebase does not mean one-click publishing. Test performance, input, networking, privacy and store requirements separately for every platform.

## Next implementation milestones

1. Replace capsule visuals with a character model, animations and better camera follow.
2. Add touch joystick/buttons for mobile.
3. Move all money and job rewards to server-authoritative logic.
4. Add PostgreSQL or another database for accounts, inventories and persistent saves.
5. Add safe interaction systems, rent, room interiors, relationships and NPC schedules.
6. Add vehicles and larger city districts.
7. Add account security, reports, moderation, rate limits, TLS and deployment monitoring before public tests.
8. Add optional real-money purchases only after platform/payment policy and legal review.

## Security note

This is a learning prototype. Do not expose the demo server publicly without authentication, rate limiting, validation, TLS, persistence and server-side economy rules. Never use real-money payments with the demo wallet.


## First public release

See [`DEPLOYMENT.md`](DEPLOYMENT.md) for step-by-step free hosting, web export, multiplayer deployment, platform requirements, fees and security limitations.
